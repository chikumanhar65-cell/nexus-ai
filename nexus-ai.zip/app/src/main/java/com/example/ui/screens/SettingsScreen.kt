package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.viewmodel.ChatViewModel

val ACCENT_PRESETS = listOf(
    Pair("Indigo", 0xFF6366F1.toInt()),
    Pair("Cyan", 0xFF06B6D4.toInt()),
    Pair("Emerald", 0xFF10B981.toInt()),
    Pair("Violet", 0xFF8B5CF6.toInt()),
    Pair("Amber", 0xFFF59E0B.toInt()),
    Pair("Rose", 0xFFF43F5E.toInt()),
    Pair("Sky Blue", 0xFF0284C7.toInt()),
    Pair("Crimson", 0xFFDC2626.toInt())
)

val BG_PRESETS = listOf(
    Pair("Pitch Black (AMOLED)", 0xFF000000.toInt()),
    Pair("Deep Midnight", 0xFF0B0F19.toInt()),
    Pair("Charcoal", 0xFF18181B.toInt()),
    Pair("Slate Navy", 0xFF0F172A.toInt()),
    Pair("Pure White", 0xFFFFFFFF.toInt()),
    Pair("Soft Light Gray", 0xFFF8FAFC.toInt())
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val currentSettings by viewModel.settings.collectAsState()
    var activeTab by remember { mutableStateOf(0) } // 0: Appearance, 1: AI Personalization, 2: Security & Privacy

    val accentColor = Color(currentSettings.customAccentColor)

    // Dialog states
    var showClearHistoryDialog by remember { mutableStateOf(false) }
    var showDeleteAllDataDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & Personalization", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Row
            PrimaryTabRow(
                selectedTabIndex = activeTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = accentColor
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = { Text("Appearance", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = { Text("AI Style", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.Psychology, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    text = { Text("Privacy & Keys", fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
            }

            when (activeTab) {
                0 -> AppearanceSettingsTab(
                    settings = currentSettings,
                    onUpdate = { viewModel.updateSettings(it) }
                )
                1 -> AiPersonalizationTab(
                    settings = currentSettings,
                    onUpdate = { viewModel.updateSettings(it) }
                )
                2 -> SecurityPrivacyTab(
                    settings = currentSettings,
                    onUpdate = { viewModel.updateSettings(it) },
                    onClearHistory = { showClearHistoryDialog = true },
                    onDeleteAllData = { showDeleteAllDataDialog = true },
                    onLogout = { showLogoutDialog = true }
                )
            }
        }
    }

    // Clear History Dialog
    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = { Text("Clear All Chat History?") },
            text = { Text("All conversation history will be erased from your local database. Your custom preferences will remain intact.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllChatHistory()
                        showClearHistoryDialog = false
                        Toast.makeText(context, "Chat history cleared", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Clear")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete All Data Dialog
    if (showDeleteAllDataDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDataDialog = false },
            title = { Text("Delete All Data & Reset?") },
            text = { Text("This will delete all conversations, messages, and reset all personalization and appearance settings to default.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAllData()
                        showDeleteAllDataDialog = false
                        Toast.makeText(context, "All data deleted & app reset", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDataDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Logout Dialog
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Log Out / Reset Session?") },
            text = { Text("This will reset your current session. Local chats remain stored until cleared.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSettings(currentSettings.copy(isLoggedIn = true))
                        showLogoutDialog = false
                        Toast.makeText(context, "Session reset successfully", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AppearanceSettingsTab(
    settings: UserSettings,
    onUpdate: (UserSettings) -> Unit
) {
    val accentColor = Color(settings.customAccentColor)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Theme Selection Section
        item {
            SectionCard(title = "Theme Mode", icon = Icons.Default.Brightness4, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.values().forEach { mode ->
                        val isSelected = settings.themeMode == mode
                        val label = when (mode) {
                            ThemeMode.SYSTEM -> "System Default (Auto)"
                            ThemeMode.LIGHT -> "Light Theme"
                            ThemeMode.DARK -> "Dark Theme (Deep Slate)"
                            ThemeMode.AMOLED -> "AMOLED Black (Pure #000000)"
                            ThemeMode.CUSTOM -> "Custom Theme"
                        }
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onUpdate(settings.copy(themeMode = mode)) }
                                .border(
                                    1.dp,
                                    if (isSelected) accentColor else Color.Transparent,
                                    RoundedCornerShape(12.dp)
                                ),
                            color = if (isSelected) accentColor.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = label,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onUpdate(settings.copy(themeMode = mode)) },
                                    colors = RadioButtonDefaults.colors(selectedColor = accentColor)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Color Customization
        item {
            SectionCard(title = "Colors & Accent", icon = Icons.Default.ColorLens, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "Accent Color",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(ACCENT_PRESETS) { (name, colorInt) ->
                            val isSelected = settings.customAccentColor == colorInt
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color(colorInt))
                                    .border(
                                        if (isSelected) 3.dp else 1.dp,
                                        if (isSelected) Color.White else Color.Transparent,
                                        CircleShape
                                    )
                                    .clickable {
                                        onUpdate(settings.copy(customAccentColor = colorInt))
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (settings.themeMode == ThemeMode.CUSTOM) {
                        Text(
                            text = "Background Palette (Custom Mode)",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(BG_PRESETS) { (name, colorInt) ->
                                val isSelected = settings.customBackgroundColor == colorInt
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(Color(colorInt))
                                        .border(
                                            if (isSelected) 3.dp else 1.dp,
                                            if (isSelected) accentColor else Color.Gray.copy(alpha = 0.4f),
                                            CircleShape
                                        )
                                        .clickable {
                                            onUpdate(settings.copy(customBackgroundColor = colorInt))
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = if (colorInt == 0xFFFFFFFF.toInt()) Color.Black else Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Typography Section
        item {
            SectionCard(title = "Typography & Sizing", icon = Icons.Default.TextFields, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "Font Family",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(FontFamilyPreference.values()) { font ->
                            val isSelected = settings.fontFamily == font
                            FilterChip(
                                selected = isSelected,
                                onClick = { onUpdate(settings.copy(fontFamily = font)) },
                                label = { Text(font.name.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() }) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = accentColor.copy(alpha = 0.2f),
                                    selectedLabelColor = accentColor
                                )
                            )
                        }
                    }

                    // Message text size slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Message Text Size", fontSize = 13.sp)
                            Text("${settings.messageTextSize.toInt()} sp", fontWeight = FontWeight.Bold, color = accentColor)
                        }
                        Slider(
                            value = settings.messageTextSize,
                            onValueChange = { onUpdate(settings.copy(messageTextSize = it)) },
                            valueRange = 12f..20f,
                            steps = 7,
                            colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor)
                        )
                    }

                    // Code text size slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Code Block Text Size", fontSize = 13.sp)
                            Text("${settings.codeTextSize.toInt()} sp", fontWeight = FontWeight.Bold, color = accentColor)
                        }
                        Slider(
                            value = settings.codeTextSize,
                            onValueChange = { onUpdate(settings.copy(codeTextSize = it)) },
                            valueRange = 10f..16f,
                            steps = 5,
                            colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor)
                        )
                    }

                    // Line spacing
                    Text(
                        text = "Line Spacing",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(Pair("Compact", 1.1f), Pair("Normal", 1.25f), Pair("Spacious", 1.5f)).forEach { (name, mult) ->
                            val isSelected = settings.lineSpacingMultiplier == mult
                            FilterChip(
                                selected = isSelected,
                                onClick = { onUpdate(settings.copy(lineSpacingMultiplier = mult)) },
                                label = { Text(name) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = accentColor.copy(alpha = 0.2f),
                                    selectedLabelColor = accentColor
                                )
                            )
                        }
                    }
                }
            }
        }

        // Chat Layout & Bubbles Section
        item {
            SectionCard(title = "Chat Layout & Bubbles", icon = Icons.Default.ChatBubbleOutline, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Chat Density
                    Text(
                        text = "Layout Density",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChatLayoutDensity.values().forEach { density ->
                            val isSelected = settings.chatDensity == density
                            FilterChip(
                                selected = isSelected,
                                onClick = { onUpdate(settings.copy(chatDensity = density)) },
                                label = { Text(density.name.lowercase().replaceFirstChar { it.uppercase() }) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = accentColor.copy(alpha = 0.2f),
                                    selectedLabelColor = accentColor
                                )
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Toggles
                    SwitchRow(
                        title = "Show Timestamps",
                        subtitle = "Display time below each chat message",
                        checked = settings.showTimestamps,
                        accentColor = accentColor,
                        onCheckedChange = { onUpdate(settings.copy(showTimestamps = it)) }
                    )

                    SwitchRow(
                        title = "Show AI Avatar",
                        subtitle = "Display avatar next to assistant messages",
                        checked = settings.showAiAvatar,
                        accentColor = accentColor,
                        onCheckedChange = { onUpdate(settings.copy(showAiAvatar = it)) }
                    )

                    SwitchRow(
                        title = "Show User Avatar",
                        subtitle = "Display avatar next to user messages",
                        checked = settings.showUserAvatar,
                        accentColor = accentColor,
                        onCheckedChange = { onUpdate(settings.copy(showUserAvatar = it)) }
                    )

                    SwitchRow(
                        title = "Rounded Message Bubbles",
                        subtitle = "Use smooth rounded corners instead of sharp corners",
                        checked = settings.roundedBubbles,
                        accentColor = accentColor,
                        onCheckedChange = { onUpdate(settings.copy(roundedBubbles = it)) }
                    )

                    // Bubble corner radius slider
                    if (settings.roundedBubbles) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Bubble Corner Radius", fontSize = 13.sp)
                                Text("${settings.bubbleCornerRadiusDp} dp", fontWeight = FontWeight.Bold, color = accentColor)
                            }
                            Slider(
                                value = settings.bubbleCornerRadiusDp.toFloat(),
                                onValueChange = { onUpdate(settings.copy(bubbleCornerRadiusDp = it.toInt())) },
                                valueRange = 8f..28f,
                                steps = 9,
                                colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiPersonalizationTab(
    settings: UserSettings,
    onUpdate: (UserSettings) -> Unit
) {
    val accentColor = Color(settings.customAccentColor)
    var assistantName by remember(settings.assistantName) { mutableStateOf(settings.assistantName) }
    var personalityText by remember(settings.aiPersonality) { mutableStateOf(settings.aiPersonality) }
    var customInstructions by remember(settings.customInstructions) { mutableStateOf(settings.customInstructions) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Assistant Identity Card
        item {
            SectionCard(title = "Assistant Identity", icon = Icons.Default.SmartToy, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = assistantName,
                        onValueChange = {
                            assistantName = it
                            onUpdate(settings.copy(assistantName = it))
                        },
                        label = { Text("Assistant Name") },
                        placeholder = { Text("e.g. Nexus AI, Aura, Nova") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = personalityText,
                        onValueChange = {
                            personalityText = it
                            onUpdate(settings.copy(aiPersonality = it))
                        },
                        label = { Text("AI Personality / Persona") },
                        placeholder = { Text("e.g. Helpful, insightful, concise and sharp") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // Response Length Preference
        item {
            SectionCard(title = "Response Length", icon = Icons.AutoMirrored.Filled.FormatAlignLeft, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ResponseLengthPreference.values().forEach { pref ->
                        val isSelected = settings.responseLength == pref
                        val desc = when (pref) {
                            ResponseLengthPreference.CONCISE -> "Short, punchy answers without unnecessary fluff"
                            ResponseLengthPreference.BALANCED -> "Balanced depth with clear structure and context"
                            ResponseLengthPreference.DETAILED -> "Deep, comprehensive explanations with full breakdown"
                        }
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onUpdate(settings.copy(responseLength = pref)) }
                                .border(
                                    1.dp,
                                    if (isSelected) accentColor else Color.Transparent,
                                    RoundedCornerShape(12.dp)
                                ),
                            color = if (isSelected) accentColor.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(pref.name.lowercase().replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onUpdate(settings.copy(responseLength = pref)) },
                                    colors = RadioButtonDefaults.colors(selectedColor = accentColor)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Tone Preference
        item {
            SectionCard(title = "Tone of Voice", icon = Icons.Default.RecordVoiceOver, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TonePreference.values().forEach { tone ->
                        val isSelected = settings.tone == tone
                        val toneDesc = when (tone) {
                            TonePreference.FORMAL -> "Professional, polished and business-ready"
                            TonePreference.FRIENDLY -> "Warm, encouraging and conversational"
                            TonePreference.CASUAL -> "Relaxed, modern and easygoing"
                            TonePreference.ACADEMIC -> "Rigorous, analytical and research-oriented"
                            TonePreference.BALANCED -> "Neutral, helpful and balanced"
                        }
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onUpdate(settings.copy(tone = tone)) }
                                .border(
                                    1.dp,
                                    if (isSelected) accentColor else Color.Transparent,
                                    RoundedCornerShape(12.dp)
                                ),
                            color = if (isSelected) accentColor.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(tone.name.lowercase().replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(toneDesc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onUpdate(settings.copy(tone = tone)) },
                                    colors = RadioButtonDefaults.colors(selectedColor = accentColor)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Custom Instructions
        item {
            SectionCard(title = "Custom System Instructions", icon = Icons.Default.EditNote, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Specify instructions that will be injected into every conversation with the AI:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = customInstructions,
                        onValueChange = {
                            customInstructions = it
                            onUpdate(settings.copy(customInstructions = it))
                        },
                        placeholder = { Text("e.g. Always write code in Kotlin. Use bullet points when summarizing. Avoid introductory pleasantries.") },
                        minLines = 4,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SecurityPrivacyTab(
    settings: UserSettings,
    onUpdate: (UserSettings) -> Unit,
    onClearHistory: () -> Unit,
    onDeleteAllData: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val accentColor = Color(settings.customAccentColor)
    var apiKeyText by remember(settings.customApiKey) { mutableStateOf(settings.customApiKey) }
    var showApiKey by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // API Key Section
        item {
            SectionCard(title = "Gemini API Key Configuration", icon = Icons.Default.VpnKey, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "The app uses Gemini 3.5 Flash for high-speed streaming. You can configure your custom API key below if needed:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = apiKeyText,
                        onValueChange = { apiKeyText = it },
                        label = { Text("Gemini API Key") },
                        placeholder = { Text("AIzaSy...") },
                        visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showApiKey = !showApiKey }) {
                                Icon(
                                    imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle API Key visibility"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                onUpdate(settings.copy(customApiKey = apiKeyText.trim()))
                                Toast.makeText(context, "API Key saved successfully", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Save Key")
                        }
                    }
                }
            }
        }

        // Privacy & Storage Explanation
        item {
            SectionCard(title = "Privacy & Data Guarantees", icon = Icons.Default.Shield, accentColor = accentColor) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PrivacyBulletPoint(
                        title = "100% On-Device Local Storage",
                        description = "All conversations and settings are stored locally on your device via Room SQLite database."
                    )
                    PrivacyBulletPoint(
                        title = "Zero Hidden Uploads",
                        description = "Images and files are only transmitted to Google Gemini when you explicitly tap Send."
                    )
                    PrivacyBulletPoint(
                        title = "Direct AI Communication",
                        description = "Requests travel directly between your device and Google's Generative AI servers without third-party tracking."
                    )
                }
            }
        }

        // Data Management & Danger Zone
        item {
            SectionCard(title = "Data Management & Account", icon = Icons.Default.ManageAccounts, accentColor = MaterialTheme.colorScheme.error) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = onClearHistory,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Clear Chat History")
                    }

                    OutlinedButton(
                        onClick = onLogout,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reset Active Session")
                    }

                    Button(
                        onClick = onDeleteAllData,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Delete All Data & Reset App")
                    }
                }
            }
        }
    }
}

@Composable
fun SectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                }
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            content()
        }
    }
}

@Composable
fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    accentColor: Color,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accentColor
            )
        )
    }
}

@Composable
fun PrivacyBulletPoint(title: String, description: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(18.dp).padding(top = 2.dp)
        )
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
