package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserSettings
import kotlinx.coroutines.delay

sealed class MarkdownElement {
    data class Heading(val level: Int, val text: String) : MarkdownElement()
    data class Paragraph(val text: String) : MarkdownElement()
    data class CodeBlock(val language: String, val code: String) : MarkdownElement()
    data class BulletList(val items: List<String>) : MarkdownElement()
    data class NumberedList(val items: List<Pair<Int, String>>) : MarkdownElement()
    data class BlockQuote(val text: String) : MarkdownElement()
    data class Table(val headers: List<String>, val rows: List<List<String>>) : MarkdownElement()
    object Divider : MarkdownElement()
}

@Composable
fun MarkdownRenderer(
    markdown: String,
    settings: UserSettings,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    codeBgColor: Color = Color(0xFF1E1E2E),
    accentColor: Color = Color(settings.customAccentColor)
) {
    val elements = remember(markdown) { parseMarkdown(markdown) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy((6 * settings.lineSpacingMultiplier).dp)
    ) {
        elements.forEach { element ->
            when (element) {
                is MarkdownElement.Heading -> {
                    val fontSize = when (element.level) {
                        1 -> (settings.messageTextSize + 6).sp
                        2 -> (settings.messageTextSize + 4).sp
                        3 -> (settings.messageTextSize + 2).sp
                        else -> (settings.messageTextSize + 1).sp
                    }
                    Text(
                        text = buildAnnotatedInline(element.text, textColor, accentColor),
                        fontSize = fontSize,
                        fontWeight = FontWeight.Bold,
                        color = textColor,
                        lineHeight = (fontSize.value * settings.lineSpacingMultiplier).sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                    )
                }

                is MarkdownElement.Paragraph -> {
                    Text(
                        text = buildAnnotatedInline(element.text, textColor, accentColor),
                        fontSize = settings.messageTextSize.sp,
                        color = textColor,
                        lineHeight = (settings.messageTextSize * settings.lineSpacingMultiplier).sp
                    )
                }

                is MarkdownElement.CodeBlock -> {
                    CodeBlockCard(
                        language = element.language,
                        code = element.code,
                        fontSize = settings.codeTextSize.sp,
                        codeBgColor = codeBgColor,
                        accentColor = accentColor
                    )
                }

                is MarkdownElement.BulletList -> {
                    Column(
                        verticalArrangement = Arrangement.spacedBy((4 * settings.lineSpacingMultiplier).dp),
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        element.items.forEach { item ->
                            Row(
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .padding(top = 7.dp)
                                        .size(5.dp)
                                        .background(accentColor, RoundedCornerShape(50))
                                )
                                Text(
                                    text = buildAnnotatedInline(item, textColor, accentColor),
                                    fontSize = settings.messageTextSize.sp,
                                    color = textColor,
                                    lineHeight = (settings.messageTextSize * settings.lineSpacingMultiplier).sp,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                            }
                        }
                    }
                }

                is MarkdownElement.NumberedList -> {
                    Column(
                        verticalArrangement = Arrangement.spacedBy((4 * settings.lineSpacingMultiplier).dp),
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        element.items.forEach { (num, item) ->
                            Row(
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "$num.",
                                    fontSize = settings.messageTextSize.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = accentColor
                                )
                                Text(
                                    text = buildAnnotatedInline(item, textColor, accentColor),
                                    fontSize = settings.messageTextSize.sp,
                                    color = textColor,
                                    lineHeight = (settings.messageTextSize * settings.lineSpacingMultiplier).sp,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                            }
                        }
                    }
                }

                is MarkdownElement.BlockQuote -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(accentColor.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(IntrinsicSize.Min)
                                .background(accentColor, RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = buildAnnotatedInline(element.text, textColor, accentColor),
                            fontSize = settings.messageTextSize.sp,
                            fontStyle = FontStyle.Italic,
                            color = textColor.copy(alpha = 0.9f),
                            lineHeight = (settings.messageTextSize * settings.lineSpacingMultiplier).sp
                        )
                    }
                }

                is MarkdownElement.Table -> {
                    TableCard(
                        headers = element.headers,
                        rows = element.rows,
                        fontSize = (settings.messageTextSize - 1).sp,
                        textColor = textColor,
                        accentColor = accentColor
                    )
                }

                MarkdownElement.Divider -> {
                    HorizontalDivider(
                        color = textColor.copy(alpha = 0.15f),
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CodeBlockCard(
    language: String,
    code: String,
    fontSize: TextUnit,
    codeBgColor: Color,
    accentColor: Color
) {
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(2000)
            copied = false
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = codeBgColor)
    ) {
        Column {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.35f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = language.ifBlank { "code" }.lowercase(),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = accentColor
                )

                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Code", code))
                        copied = true
                        Toast.makeText(context, "Code copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    AnimatedVisibility(
                        visible = copied,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Copied",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    if (!copied) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy code",
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Code content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(12.dp)
            ) {
                Text(
                    text = code,
                    fontFamily = FontFamily.Monospace,
                    fontSize = fontSize,
                    color = Color(0xFFECEFF4),
                    lineHeight = (fontSize.value * 1.35f).sp
                )
            }
        }
    }
}

@Composable
fun TableCard(
    headers: List<String>,
    rows: List<List<String>>,
    fontSize: TextUnit,
    textColor: Color,
    accentColor: Color
) {
    val scrollState = rememberScrollState()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .horizontalScroll(scrollState)
                .padding(8.dp)
        ) {
            // Headers
            Row(
                modifier = Modifier
                    .background(accentColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .padding(vertical = 6.dp, horizontal = 8.dp)
            ) {
                headers.forEach { header ->
                    Text(
                        text = header,
                        fontWeight = FontWeight.Bold,
                        fontSize = fontSize,
                        color = accentColor,
                        modifier = Modifier
                            .widthIn(min = 90.dp)
                            .padding(end = 12.dp)
                    )
                }
            }

            HorizontalDivider(
                color = textColor.copy(alpha = 0.2f),
                thickness = 1.dp,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            // Rows
            rows.forEachIndexed { index, row ->
                val rowBg = if (index % 2 == 0) Color.Transparent else textColor.copy(alpha = 0.04f)
                Row(
                    modifier = Modifier
                        .background(rowBg, RoundedCornerShape(4.dp))
                        .padding(vertical = 6.dp, horizontal = 8.dp)
                ) {
                    row.forEach { cell ->
                        Text(
                            text = cell,
                            fontSize = fontSize,
                            color = textColor,
                            modifier = Modifier
                                .widthIn(min = 90.dp)
                                .padding(end = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

fun buildAnnotatedInline(
    text: String,
    defaultColor: Color,
    accentColor: Color
): AnnotatedString {
    return buildAnnotatedString {
        var cursor = 0
        val regex = Regex("(`[^`]+`)|(\\*\\*([^*]+)\\*\\*)|(\\*([^*]+)\\*)|(~~([^~]+)~~)")
        val matches = regex.findAll(text)

        for (match in matches) {
            val range = match.range
            if (range.first > cursor) {
                append(text.substring(cursor, range.first))
            }

            val value = match.value
            when {
                // Inline code `code`
                value.startsWith("`") && value.endsWith("`") && value.length >= 2 -> {
                    withStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            background = accentColor.copy(alpha = 0.15f),
                            color = accentColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    ) {
                        append(" ${value.substring(1, value.length - 1)} ")
                    }
                }
                // Bold **text**
                value.startsWith("**") && value.endsWith("**") && value.length >= 4 -> {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(value.substring(2, value.length - 2))
                    }
                }
                // Italic *text*
                value.startsWith("*") && value.endsWith("*") && value.length >= 2 -> {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(value.substring(1, value.length - 1))
                    }
                }
                // Strikethrough ~~text~~
                value.startsWith("~~") && value.endsWith("~~") && value.length >= 4 -> {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(value.substring(2, value.length - 2))
                    }
                }
                else -> {
                    append(value)
                }
            }
            cursor = range.last + 1
        }

        if (cursor < text.length) {
            append(text.substring(cursor))
        }
    }
}

fun parseMarkdown(raw: String): List<MarkdownElement> {
    val lines = raw.lines()
    val elements = mutableListOf<MarkdownElement>()
    var i = 0

    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trim()

        when {
            // Code block ```
            trimmed.startsWith("```") -> {
                val lang = trimmed.removePrefix("```").trim()
                val codeBuilder = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) {
                    codeBuilder.append(lines[i]).append("\n")
                    i++
                }
                elements.add(MarkdownElement.CodeBlock(lang, codeBuilder.toString().trimEnd()))
            }

            // Headings
            trimmed.startsWith("### ") -> {
                elements.add(MarkdownElement.Heading(3, trimmed.removePrefix("### ").trim()))
            }
            trimmed.startsWith("## ") -> {
                elements.add(MarkdownElement.Heading(2, trimmed.removePrefix("## ").trim()))
            }
            trimmed.startsWith("# ") -> {
                elements.add(MarkdownElement.Heading(1, trimmed.removePrefix("# ").trim()))
            }

            // Horizontal rules
            trimmed == "---" || trimmed == "***" || trimmed == "___" -> {
                elements.add(MarkdownElement.Divider)
            }

            // Blockquotes
            trimmed.startsWith("> ") || trimmed == ">" -> {
                val quoteLines = mutableListOf<String>()
                while (i < lines.size && (lines[i].trim().startsWith(">") || lines[i].trim().startsWith("> "))) {
                    quoteLines.add(lines[i].trim().removePrefix(">").trim())
                    i++
                }
                i--
                elements.add(MarkdownElement.BlockQuote(quoteLines.joinToString(" ")))
            }

            // Bullet list
            trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("• ") -> {
                val items = mutableListOf<String>()
                while (i < lines.size && (lines[i].trim().startsWith("- ") || lines[i].trim().startsWith("* ") || lines[i].trim().startsWith("• "))) {
                    val item = lines[i].trim().substring(2).trim()
                    items.add(item)
                    i++
                }
                i--
                elements.add(MarkdownElement.BulletList(items))
            }

            // Numbered list
            trimmed.matches(Regex("^\\d+\\.\\s+.*")) -> {
                val items = mutableListOf<Pair<Int, String>>()
                while (i < lines.size && lines[i].trim().matches(Regex("^\\d+\\.\\s+.*"))) {
                    val cur = lines[i].trim()
                    val dotIdx = cur.indexOf('.')
                    val num = cur.substring(0, dotIdx).toIntOrNull() ?: (items.size + 1)
                    val text = cur.substring(dotIdx + 1).trim()
                    items.add(Pair(num, text))
                    i++
                }
                i--
                elements.add(MarkdownElement.NumberedList(items))
            }

            // Table (| a | b |)
            trimmed.startsWith("|") && trimmed.endsWith("|") -> {
                val tableLines = mutableListOf<String>()
                while (i < lines.size && lines[i].trim().startsWith("|") && lines[i].trim().endsWith("|")) {
                    tableLines.add(lines[i].trim())
                    i++
                }
                i--
                if (tableLines.size >= 2) {
                    val headerRow = tableLines[0].split("|").map { it.trim() }.filter { it.isNotEmpty() }
                    val dataRows = tableLines.drop(1)
                        .filterNot { row -> row.replace("|", "").replace("-", "").replace(":", "").trim().isEmpty() }
                        .map { row -> row.split("|").map { it.trim() }.filter { it.isNotEmpty() } }
                    elements.add(MarkdownElement.Table(headerRow, dataRows))
                } else {
                    elements.add(MarkdownElement.Paragraph(tableLines.joinToString(" ")))
                }
            }

            // Normal text / paragraph
            trimmed.isNotEmpty() -> {
                val paraLines = mutableListOf<String>()
                while (i < lines.size && lines[i].trim().isNotEmpty() &&
                    !lines[i].trim().startsWith("```") &&
                    !lines[i].trim().startsWith("#") &&
                    !lines[i].trim().startsWith("- ") &&
                    !lines[i].trim().startsWith(">") &&
                    !lines[i].trim().startsWith("|") &&
                    !lines[i].trim().matches(Regex("^\\d+\\.\\s+.*"))
                ) {
                    paraLines.add(lines[i].trim())
                    i++
                }
                i--
                elements.add(MarkdownElement.Paragraph(paraLines.joinToString(" ")))
            }
        }
        i++
    }

    return elements
}
