package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.data.ThemeMode
import com.example.data.UserSettings

private val DarkDefaultColorScheme = darkColorScheme(
    primary = Color(0xFF818CF8), // Indigo
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF312E81),
    onPrimaryContainer = Color(0xFFE0E7FF),
    secondary = Color(0xFF38BDF8), // Cyan
    onSecondary = Color(0xFF0F172A),
    secondaryContainer = Color(0xFF0369A1),
    onSecondaryContainer = Color(0xFFE0F2FE),
    tertiary = Color(0xFFA78BFA), // Purple
    background = Color(0xFF0B0F19),
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF111827),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF1F2937),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF374151)
)

private val AmoledColorScheme = darkColorScheme(
    primary = Color(0xFF6366F1),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1E1B4B),
    onPrimaryContainer = Color(0xFFE0E7FF),
    secondary = Color(0xFF06B6D4),
    onSecondary = Color.Black,
    background = Color(0xFF000000), // Pure AMOLED Pitch Black
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF121212),
    onSurfaceVariant = Color(0xFFE2E8F0),
    outline = Color(0xFF262626)
)

private val LightDefaultColorScheme = lightColorScheme(
    primary = Color(0xFF4F46E5),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEEF2FF),
    onPrimaryContainer = Color(0xFF312E81),
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF075985),
    tertiary = Color(0xFF7C3AED),
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFE2E8F0)
)

@Composable
fun NexusTheme(
    settings: UserSettings = UserSettings(),
    content: @Composable () -> Unit
) {
    val systemInDark = isSystemInDarkTheme()
    val isDark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> systemInDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.AMOLED -> true
        ThemeMode.CUSTOM -> true
    }

    val colorScheme = when (settings.themeMode) {
        ThemeMode.SYSTEM -> {
            if (systemInDark) DarkDefaultColorScheme else LightDefaultColorScheme
        }
        ThemeMode.LIGHT -> LightDefaultColorScheme
        ThemeMode.DARK -> DarkDefaultColorScheme
        ThemeMode.AMOLED -> AmoledColorScheme
        ThemeMode.CUSTOM -> {
            val customAccent = Color(settings.customAccentColor)
            val customBg = Color(settings.customBackgroundColor)
            val customSurface = Color(settings.customChatBubbleColor)
            darkColorScheme(
                primary = customAccent,
                onPrimary = Color.White,
                primaryContainer = customAccent.copy(alpha = 0.25f),
                onPrimaryContainer = Color.White,
                secondary = customAccent,
                background = customBg,
                onBackground = Color(settings.customTextColor),
                surface = customSurface,
                onSurface = Color(settings.customTextColor),
                surfaceVariant = customSurface.copy(alpha = 0.8f),
                onSurfaceVariant = Color(settings.customTextColor).copy(alpha = 0.75f),
                outline = customAccent.copy(alpha = 0.3f)
            )
        }
    }

    val typography = createAppTypography(settings.fontFamily, settings.fontSizeScale)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        content = content
    )
}

// Keep backwards-compatible wrapper
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    NexusTheme(content = content)
}
