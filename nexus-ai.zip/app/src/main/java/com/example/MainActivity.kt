package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.NexusTheme
import com.example.viewmodel.ChatViewModel
import com.example.viewmodel.ScreenDestination

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by viewModel.settings.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()

            NexusTheme(settings = settings) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            fadeIn() togetherWith fadeOut()
                        },
                        label = "ScreenTransition"
                    ) { target ->
                        when (target) {
                            is ScreenDestination.Home -> {
                                HomeScreen(
                                    viewModel = viewModel,
                                    onNavigateToChat = { convId ->
                                        viewModel.navigateTo(ScreenDestination.Chat(convId))
                                    },
                                    onNavigateToSearch = {
                                        viewModel.navigateTo(ScreenDestination.Search)
                                    },
                                    onNavigateToSettings = {
                                        viewModel.navigateTo(ScreenDestination.Settings)
                                    },
                                    onOpenVoiceShortcut = {
                                        viewModel.createNewChat { convId ->
                                            viewModel.startVoiceInput(
                                                onResult = { },
                                                onError = { }
                                            )
                                        }
                                    },
                                    onOpenImageShortcut = {
                                        viewModel.createNewChat()
                                    }
                                )
                            }

                            is ScreenDestination.Chat -> {
                                BackHandler {
                                    viewModel.navigateTo(ScreenDestination.Home)
                                }
                                ChatScreen(
                                    viewModel = viewModel,
                                    conversationId = target.conversationId,
                                    onBack = { viewModel.navigateTo(ScreenDestination.Home) }
                                )
                            }

                            is ScreenDestination.Settings -> {
                                BackHandler {
                                    viewModel.navigateTo(ScreenDestination.Home)
                                }
                                SettingsScreen(
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateTo(ScreenDestination.Home) }
                                )
                            }

                            is ScreenDestination.Search -> {
                                BackHandler {
                                    viewModel.navigateTo(ScreenDestination.Home)
                                }
                                SearchScreen(
                                    viewModel = viewModel,
                                    onNavigateToChat = { convId ->
                                        viewModel.navigateTo(ScreenDestination.Chat(convId))
                                    },
                                    onBack = { viewModel.navigateTo(ScreenDestination.Home) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
