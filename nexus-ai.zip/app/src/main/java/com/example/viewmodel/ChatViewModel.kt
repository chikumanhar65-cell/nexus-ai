package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.*
import com.example.network.ChatMessagePayload
import com.example.network.GeminiService
import com.example.network.ImageUtils
import com.example.voice.VoiceManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.InputStream
import java.util.UUID

data class AttachedMedia(
    val uri: Uri? = null,
    val bitmap: Bitmap? = null,
    val mimeType: String = "image/jpeg",
    val base64Data: String = "",
    val fileName: String = ""
)

data class AttachedDoc(
    val fileName: String,
    val textContent: String
)

sealed class ScreenDestination {
    object Home : ScreenDestination()
    data class Chat(val conversationId: String) : ScreenDestination()
    object Settings : ScreenDestination()
    object Search : ScreenDestination()
}

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "nexus_ai_database"
    ).fallbackToDestructiveMigration(true).build()

    private val conversationDao = db.conversationDao()
    private val messageDao = db.chatMessageDao()
    private val settingsRepo = SettingsRepository(application)
    private val geminiService = GeminiService()
    val voiceManager = VoiceManager(application)

    val settings: StateFlow<UserSettings> = settingsRepo.settings

    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Home)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val _currentConversationId = MutableStateFlow<String?>(null)
    val currentConversationId: StateFlow<String?> = _currentConversationId.asStateFlow()

    private val _currentConversation = MutableStateFlow<ConversationEntity?>(null)
    val currentConversation: StateFlow<ConversationEntity?> = _currentConversation.asStateFlow()

    private val _conversations = MutableStateFlow<List<ConversationEntity>>(emptyList())
    val conversations: StateFlow<List<ConversationEntity>> = _conversations.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredConversations = combine(conversationDao.getAllConversations(), _searchQuery) { list, query ->
        if (query.isBlank()) list
        else list.filter { it.title.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _messages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val messages: StateFlow<List<ChatMessageEntity>> = _messages.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _attachedImages = MutableStateFlow<List<AttachedMedia>>(emptyList())
    val attachedImages: StateFlow<List<AttachedMedia>> = _attachedImages.asStateFlow()

    private val _attachedDocs = MutableStateFlow<List<AttachedDoc>>(emptyList())
    val attachedDocs: StateFlow<List<AttachedDoc>> = _attachedDocs.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var activeStreamingJob: Job? = null

    init {
        viewModelScope.launch {
            conversationDao.getAllConversations().collect { list ->
                _conversations.value = list
            }
        }
    }

    fun navigateTo(screen: ScreenDestination) {
        _currentScreen.value = screen
        if (screen is ScreenDestination.Chat) {
            loadConversation(screen.conversationId)
        }
    }

    fun setInputText(text: String) {
        _inputText.value = text
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun createNewChat(initialPrompt: String? = null, onCreated: ((String) -> Unit)? = null) {
        viewModelScope.launch {
            val newId = UUID.randomUUID().toString()
            val newConv = ConversationEntity(
                id = newId,
                title = "New Chat",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            conversationDao.insertConversation(newConv)
            _currentConversationId.value = newId
            _currentConversation.value = newConv
            _messages.value = emptyList()
            _attachedImages.value = emptyList()
            _attachedDocs.value = emptyList()
            _currentScreen.value = ScreenDestination.Chat(newId)
            onCreated?.invoke(newId)

            if (!initialPrompt.isNullOrBlank()) {
                _inputText.value = initialPrompt
                sendMessage()
            }
        }
    }

    fun loadConversation(id: String) {
        _currentConversationId.value = id
        viewModelScope.launch {
            _currentConversation.value = conversationDao.getConversationById(id)
            messageDao.getMessagesForConversation(id).collect { msgList ->
                _messages.value = msgList
            }
        }
    }

    fun addImage(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bitmap != null) {
                    val base64 = ImageUtils.bitmapToBase64(bitmap)
                    val media = AttachedMedia(
                        uri = uri,
                        bitmap = bitmap,
                        mimeType = "image/jpeg",
                        base64Data = base64,
                        fileName = "photo_${System.currentTimeMillis()}.jpg"
                    )
                    _attachedImages.value = _attachedImages.value + media
                }
            } catch (e: Exception) {
                Log.e("ChatViewModel", "Error loading image from uri", e)
                _errorMessage.value = "Failed to load image: ${e.localizedMessage}"
            }
        }
    }

    fun addCameraBitmap(bitmap: Bitmap) {
        viewModelScope.launch {
            try {
                val base64 = ImageUtils.bitmapToBase64(bitmap)
                val media = AttachedMedia(
                    bitmap = bitmap,
                    mimeType = "image/jpeg",
                    base64Data = base64,
                    fileName = "camera_${System.currentTimeMillis()}.jpg"
                )
                _attachedImages.value = _attachedImages.value + media
            } catch (e: Exception) {
                Log.e("ChatViewModel", "Error processing camera image", e)
                _errorMessage.value = "Failed to process photo."
            }
        }
    }

    fun removeImage(index: Int) {
        val current = _attachedImages.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _attachedImages.value = current
        }
    }

    fun addDocument(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream != null) {
                    val text = ImageUtils.readStreamAsText(inputStream)
                    val fileName = "doc_${System.currentTimeMillis()}.txt"
                    _attachedDocs.value = _attachedDocs.value + AttachedDoc(fileName, text)
                }
            } catch (e: Exception) {
                Log.e("ChatViewModel", "Error reading document", e)
                _errorMessage.value = "Failed to read document: ${e.localizedMessage}"
            }
        }
    }

    fun removeDoc(index: Int) {
        val current = _attachedDocs.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _attachedDocs.value = current
        }
    }

    fun sendMessage() {
        val text = _inputText.value.trim()
        val images = _attachedImages.value
        val docs = _attachedDocs.value

        if (text.isBlank() && images.isEmpty() && docs.isEmpty()) return
        if (_isGenerating.value) return

        val conversationId = _currentConversationId.value ?: run {
            createNewChat()
            return
        }

        // Reset input fields
        _inputText.value = ""
        _attachedImages.value = emptyList()
        _attachedDocs.value = emptyList()

        viewModelScope.launch {
            // Update conversation title if first message
            val currentMsgs = messageDao.getMessagesForConversationSync(conversationId)
            if (currentMsgs.isEmpty()) {
                val titleCandidate = when {
                    text.isNotBlank() -> text.take(35).replace("\n", " ").trim()
                    images.isNotEmpty() -> "Image Analysis"
                    docs.isNotEmpty() -> "Document Discussion"
                    else -> "New Chat"
                }
                conversationDao.updateTitle(conversationId, titleCandidate, System.currentTimeMillis())
                _currentConversation.value = conversationDao.getConversationById(conversationId)
            } else {
                conversationDao.updateTitle(conversationId, _currentConversation.value?.title ?: "Chat", System.currentTimeMillis())
            }

            // Construct JSON for images if present
            val imagePayloads = images.map { Pair(it.mimeType, it.base64Data) }
            val docPayloads = docs.map { Pair(it.fileName, it.textContent) }

            val imageUrisJson = if (images.isNotEmpty()) {
                val jsonArr = JSONArray()
                images.forEach { jsonArr.put(it.base64Data) }
                jsonArr.toString()
            } else ""

            val docNamesJson = if (docs.isNotEmpty()) {
                val jsonArr = JSONArray()
                docs.forEach { jsonArr.put(it.fileName) }
                jsonArr.toString()
            } else ""

            // Save user message
            val userMsg = ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                conversationId = conversationId,
                role = "user",
                content = text,
                timestamp = System.currentTimeMillis(),
                imageUris = imageUrisJson,
                documentNames = docNamesJson
            )
            messageDao.insertMessage(userMsg)

            // Prepare Assistant response placeholder
            val assistantMsgId = UUID.randomUUID().toString()
            val initialAssistantMsg = ChatMessageEntity(
                id = assistantMsgId,
                conversationId = conversationId,
                role = "assistant",
                content = "",
                timestamp = System.currentTimeMillis(),
                isStreaming = true
            )
            messageDao.insertMessage(initialAssistantMsg)

            // Build history payload for Gemini
            val fullHistory = buildChatPayload(conversationId, text, imagePayloads, docPayloads)

            // Start streaming
            _isGenerating.value = true
            val accumulatedText = StringBuilder()

            activeStreamingJob = launch {
                try {
                    val systemPrompt = buildSystemInstruction(settings.value)
                    val apiKeyOverride = settings.value.customApiKey.takeIf { it.isNotBlank() }

                    geminiService.streamChat(
                        history = fullHistory,
                        systemInstruction = systemPrompt,
                        apiKeyOverride = apiKeyOverride,
                        model = GeminiService.DEFAULT_MODEL
                    ).collect { chunk ->
                        accumulatedText.append(chunk)
                        val updatedMsg = initialAssistantMsg.copy(
                            content = accumulatedText.toString(),
                            isStreaming = true
                        )
                        messageDao.updateMessage(updatedMsg)
                    }

                    // Complete streaming
                    val finalMsg = initialAssistantMsg.copy(
                        content = accumulatedText.toString(),
                        isStreaming = false
                    )
                    messageDao.updateMessage(finalMsg)
                } catch (e: Exception) {
                    Log.e("ChatViewModel", "Generation error", e)
                    val errorMsg = initialAssistantMsg.copy(
                        content = if (accumulatedText.isNotEmpty()) accumulatedText.toString() else "❌ Request was interrupted or failed.",
                        isStreaming = false,
                        isError = accumulatedText.isEmpty()
                    )
                    messageDao.updateMessage(errorMsg)
                } finally {
                    _isGenerating.value = false
                    activeStreamingJob = null
                }
            }
        }
    }

    private suspend fun buildChatPayload(
        conversationId: String,
        currentUserText: String,
        currentImages: List<Pair<String, String>>,
        currentDocs: List<Pair<String, String>>
    ): List<ChatMessagePayload> {
        val existingMsgs = messageDao.getMessagesForConversationSync(conversationId)
        val historyPayloads = mutableListOf<ChatMessagePayload>()

        for (msg in existingMsgs) {
            if (msg.role == "user") {
                historyPayloads.add(
                    ChatMessagePayload(
                        role = "user",
                        text = msg.content
                    )
                )
            } else if (msg.role == "assistant" && msg.content.isNotBlank() && !msg.isError) {
                historyPayloads.add(
                    ChatMessagePayload(
                        role = "model",
                        text = msg.content
                    )
                )
            }
        }

        // Add current user turn with media if not already present
        if (historyPayloads.isEmpty() || historyPayloads.last().text != currentUserText) {
            historyPayloads.add(
                ChatMessagePayload(
                    role = "user",
                    text = currentUserText,
                    imagesBase64 = currentImages,
                    documentTexts = currentDocs
                )
            )
        } else {
            // Update last payload with media
            val last = historyPayloads.last()
            historyPayloads[historyPayloads.lastIndex] = last.copy(
                imagesBase64 = currentImages,
                documentTexts = currentDocs
            )
        }

        return historyPayloads
    }

    private fun buildSystemInstruction(userSettings: UserSettings): String {
        val lengthInstruction = when (userSettings.responseLength) {
            ResponseLengthPreference.CONCISE -> "Keep your responses concise, direct, and focused without unnecessary preamble."
            ResponseLengthPreference.BALANCED -> "Provide balanced, well-structured responses with clear explanations."
            ResponseLengthPreference.DETAILED -> "Provide in-depth, comprehensive explanations with thorough background details, examples, and breakdown."
        }

        val toneInstruction = when (userSettings.tone) {
            TonePreference.FORMAL -> "Maintain a professional, formal, and polished tone."
            TonePreference.FRIENDLY -> "Maintain an empathetic, warm, and friendly conversational tone."
            TonePreference.CASUAL -> "Maintain a relaxed, casual, and approachable tone."
            TonePreference.ACADEMIC -> "Maintain an academic, analytical, and rigorous tone."
            TonePreference.BALANCED -> "Maintain a balanced, helpful, and natural tone."
        }

        return buildString {
            append("You are ${userSettings.assistantName}, an advanced AI assistant powered by Google Gemini. ")
            append("Personality: ${userSettings.aiPersonality}. ")
            append("$lengthInstruction $toneInstruction ")
            if (userSettings.customInstructions.isNotBlank()) {
                append("\nUser Custom Instructions: ${userSettings.customInstructions}\n")
            }
            append("Always format your output in clean Markdown (headings, bold, lists, code blocks with syntax highlighting language tags, and tables when presenting tabular data).")
        }
    }

    fun stopGenerating() {
        activeStreamingJob?.cancel()
        activeStreamingJob = null
        _isGenerating.value = false

        // Update current streaming message to finished
        viewModelScope.launch {
            val convId = _currentConversationId.value ?: return@launch
            val msgs = messageDao.getMessagesForConversationSync(convId)
            val streamingMsg = msgs.lastOrNull { it.isStreaming }
            if (streamingMsg != null) {
                messageDao.updateMessage(streamingMsg.copy(isStreaming = false))
            }
        }
    }

    fun regenerateLastResponse() {
        val convId = _currentConversationId.value ?: return
        if (_isGenerating.value) return

        viewModelScope.launch {
            val msgs = messageDao.getMessagesForConversationSync(convId)
            if (msgs.isEmpty()) return@launch

            val lastAssistantMsg = msgs.lastOrNull { it.role == "assistant" }
            if (lastAssistantMsg != null) {
                messageDao.deleteMessage(lastAssistantMsg.id)
            }

            // Find last user message
            val lastUserMsg = msgs.lastOrNull { it.role == "user" } ?: return@launch

            // Prepare Assistant response placeholder
            val assistantMsgId = UUID.randomUUID().toString()
            val initialAssistantMsg = ChatMessageEntity(
                id = assistantMsgId,
                conversationId = convId,
                role = "assistant",
                content = "",
                timestamp = System.currentTimeMillis(),
                isStreaming = true
            )
            messageDao.insertMessage(initialAssistantMsg)

            val fullHistory = buildChatPayload(convId, lastUserMsg.content, emptyList(), emptyList())

            _isGenerating.value = true
            val accumulatedText = StringBuilder()

            activeStreamingJob = launch {
                try {
                    val systemPrompt = buildSystemInstruction(settings.value)
                    val apiKeyOverride = settings.value.customApiKey.takeIf { it.isNotBlank() }

                    geminiService.streamChat(
                        history = fullHistory,
                        systemInstruction = systemPrompt,
                        apiKeyOverride = apiKeyOverride
                    ).collect { chunk ->
                        accumulatedText.append(chunk)
                        val updatedMsg = initialAssistantMsg.copy(
                            content = accumulatedText.toString(),
                            isStreaming = true
                        )
                        messageDao.updateMessage(updatedMsg)
                    }

                    val finalMsg = initialAssistantMsg.copy(
                        content = accumulatedText.toString(),
                        isStreaming = false
                    )
                    messageDao.updateMessage(finalMsg)
                } catch (e: Exception) {
                    val errorMsg = initialAssistantMsg.copy(
                        content = if (accumulatedText.isNotEmpty()) accumulatedText.toString() else "❌ Regeneration failed: ${e.localizedMessage}",
                        isStreaming = false
                    )
                    messageDao.updateMessage(errorMsg)
                } finally {
                    _isGenerating.value = false
                    activeStreamingJob = null
                }
            }
        }
    }

    fun editAndResend(messageId: String, newContent: String) {
        val convId = _currentConversationId.value ?: return
        viewModelScope.launch {
            // Delete messages from this point onward
            val msgs = messageDao.getMessagesForConversationSync(convId)
            val targetIdx = msgs.indexOfFirst { it.id == messageId }
            if (targetIdx != -1) {
                for (i in targetIdx until msgs.size) {
                    messageDao.deleteMessage(msgs[i].id)
                }
            }
            _inputText.value = newContent
            sendMessage()
        }
    }

    fun startVoiceInput(onResult: (String) -> Unit, onError: (String) -> Unit) {
        voiceManager.startListening(
            onResult = { text ->
                _inputText.value = if (_inputText.value.isBlank()) text else "${_inputText.value} $text"
                onResult(text)
            },
            onError = onError
        )
    }

    fun stopVoiceInput() {
        voiceManager.stopListening()
    }

    fun toggleSpeakMessage(messageId: String, text: String) {
        val rate = settings.value.ttsSpeechRate
        val pitch = settings.value.ttsPitch
        voiceManager.speak(messageId, text, rate, pitch)
    }

    fun togglePinConversation(id: String, isPinned: Boolean) {
        viewModelScope.launch {
            conversationDao.setPinned(id, !isPinned)
            if (_currentConversationId.value == id) {
                _currentConversation.value = conversationDao.getConversationById(id)
            }
        }
    }

    fun renameConversation(id: String, newTitle: String) {
        if (newTitle.isBlank()) return
        viewModelScope.launch {
            conversationDao.updateTitle(id, newTitle.trim(), System.currentTimeMillis())
            if (_currentConversationId.value == id) {
                _currentConversation.value = conversationDao.getConversationById(id)
            }
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            conversationDao.deleteConversation(id)
            messageDao.deleteMessagesForConversation(id)
            if (_currentConversationId.value == id) {
                _currentConversationId.value = null
                _currentConversation.value = null
                _messages.value = emptyList()
                _currentScreen.value = ScreenDestination.Home
            }
        }
    }

    fun clearAllChatHistory() {
        viewModelScope.launch {
            conversationDao.deleteAllConversations()
            messageDao.deleteAllMessages()
            _currentConversationId.value = null
            _currentConversation.value = null
            _messages.value = emptyList()
            _currentScreen.value = ScreenDestination.Home
        }
    }

    fun deleteAllData() {
        viewModelScope.launch {
            conversationDao.deleteAllConversations()
            messageDao.deleteAllMessages()
            settingsRepo.resetToDefaults()
            _currentConversationId.value = null
            _currentConversation.value = null
            _messages.value = emptyList()
            _currentScreen.value = ScreenDestination.Home
        }
    }

    fun updateSettings(newSettings: UserSettings) {
        settingsRepo.updateSettings(newSettings)
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
