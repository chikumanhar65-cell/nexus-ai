package com.example.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode {
    SYSTEM, LIGHT, DARK, AMOLED, CUSTOM
}

enum class FontFamilyPreference {
    SYSTEM_DEFAULT, SANS_SERIF, SERIF, MONOSPACE, CURSIVE
}

enum class ResponseLengthPreference {
    CONCISE, BALANCED, DETAILED
}

enum class TonePreference {
    BALANCED, FORMAL, FRIENDLY, CASUAL, ACADEMIC
}

enum class ChatLayoutDensity {
    COMPACT, COMFORTABLE, SPACIOUS
}

data class UserSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val customAccentColor: Int = 0xFF6366F1.toInt(), // Indigo
    val customBackgroundColor: Int = 0xFF0D0F17.toInt(),
    val customChatBubbleColor: Int = 0xFF1E2235.toInt(),
    val customUserMessageColor: Int = 0xFF4F46E5.toInt(),
    val customAiMessageColor: Int = 0xFF181B2A.toInt(),
    val customTextColor: Int = 0xFFF1F5F9.toInt(),

    // Font customization
    val fontFamily: FontFamilyPreference = FontFamilyPreference.SYSTEM_DEFAULT,
    val fontSizeScale: Float = 1.0f, // 0.85 to 1.3
    val messageTextSize: Float = 15f,
    val codeTextSize: Float = 13f,
    val lineSpacingMultiplier: Float = 1.25f,

    // Chat UI customization
    val chatDensity: ChatLayoutDensity = ChatLayoutDensity.COMFORTABLE,
    val showTimestamps: Boolean = true,
    val showAiAvatar: Boolean = true,
    val showUserAvatar: Boolean = true,
    val roundedBubbles: Boolean = true,
    val bubbleCornerRadiusDp: Int = 18,
    val maxBubbleWidthPercent: Float = 0.85f,

    // AI Personalization
    val assistantName: String = "Nexus AI",
    val aiPersonality: String = "Helpful, insightful, and precise",
    val responseLength: ResponseLengthPreference = ResponseLengthPreference.BALANCED,
    val tone: TonePreference = TonePreference.FRIENDLY,
    val customInstructions: String = "Be helpful, provide clear markdown structure, highlight key takeaways, and ensure code snippets are idiomatic and commented.",
    
    // Security & Custom API Key
    val customApiKey: String = "",
    val isLoggedIn: Boolean = true,
    val ttsSpeechRate: Float = 1.0f,
    val ttsPitch: Float = 1.0f
)

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("nexus_ai_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private fun loadSettings(): UserSettings {
        return UserSettings(
            themeMode = ThemeMode.valueOf(prefs.getString("theme_mode", ThemeMode.DARK.name) ?: ThemeMode.DARK.name),
            customAccentColor = prefs.getInt("custom_accent_color", 0xFF6366F1.toInt()),
            customBackgroundColor = prefs.getInt("custom_background_color", 0xFF0D0F17.toInt()),
            customChatBubbleColor = prefs.getInt("custom_chat_bubble_color", 0xFF1E2235.toInt()),
            customUserMessageColor = prefs.getInt("custom_user_message_color", 0xFF4F46E5.toInt()),
            customAiMessageColor = prefs.getInt("custom_ai_message_color", 0xFF181B2A.toInt()),
            customTextColor = prefs.getInt("custom_text_color", 0xFFF1F5F9.toInt()),
            fontFamily = FontFamilyPreference.valueOf(prefs.getString("font_family", FontFamilyPreference.SYSTEM_DEFAULT.name) ?: FontFamilyPreference.SYSTEM_DEFAULT.name),
            fontSizeScale = prefs.getFloat("font_size_scale", 1.0f),
            messageTextSize = prefs.getFloat("message_text_size", 15f),
            codeTextSize = prefs.getFloat("code_text_size", 13f),
            lineSpacingMultiplier = prefs.getFloat("line_spacing_multiplier", 1.25f),
            chatDensity = ChatLayoutDensity.valueOf(prefs.getString("chat_density", ChatLayoutDensity.COMFORTABLE.name) ?: ChatLayoutDensity.COMFORTABLE.name),
            showTimestamps = prefs.getBoolean("show_timestamps", true),
            showAiAvatar = prefs.getBoolean("show_ai_avatar", true),
            showUserAvatar = prefs.getBoolean("show_user_avatar", true),
            roundedBubbles = prefs.getBoolean("rounded_bubbles", true),
            bubbleCornerRadiusDp = prefs.getInt("bubble_corner_radius_dp", 18),
            maxBubbleWidthPercent = prefs.getFloat("max_bubble_width_percent", 0.85f),
            assistantName = prefs.getString("assistant_name", "Nexus AI") ?: "Nexus AI",
            aiPersonality = prefs.getString("ai_personality", "Helpful, insightful, and precise") ?: "Helpful, insightful, and precise",
            responseLength = ResponseLengthPreference.valueOf(prefs.getString("response_length", ResponseLengthPreference.BALANCED.name) ?: ResponseLengthPreference.BALANCED.name),
            tone = TonePreference.valueOf(prefs.getString("tone", TonePreference.FRIENDLY.name) ?: TonePreference.FRIENDLY.name),
            customInstructions = prefs.getString("custom_instructions", "Be helpful, provide clear markdown structure, highlight key takeaways, and ensure code snippets are idiomatic and commented.") ?: "",
            customApiKey = prefs.getString("custom_api_key", "") ?: "",
            isLoggedIn = prefs.getBoolean("is_logged_in", true),
            ttsSpeechRate = prefs.getFloat("tts_speech_rate", 1.0f),
            ttsPitch = prefs.getFloat("tts_pitch", 1.0f)
        )
    }

    fun updateSettings(newSettings: UserSettings) {
        prefs.edit().apply {
            putString("theme_mode", newSettings.themeMode.name)
            putInt("custom_accent_color", newSettings.customAccentColor)
            putInt("custom_background_color", newSettings.customBackgroundColor)
            putInt("custom_chat_bubble_color", newSettings.customChatBubbleColor)
            putInt("custom_user_message_color", newSettings.customUserMessageColor)
            putInt("custom_ai_message_color", newSettings.customAiMessageColor)
            putInt("custom_text_color", newSettings.customTextColor)
            putString("font_family", newSettings.fontFamily.name)
            putFloat("font_size_scale", newSettings.fontSizeScale)
            putFloat("message_text_size", newSettings.messageTextSize)
            putFloat("code_text_size", newSettings.codeTextSize)
            putFloat("line_spacing_multiplier", newSettings.lineSpacingMultiplier)
            putString("chat_density", newSettings.chatDensity.name)
            putBoolean("show_timestamps", newSettings.showTimestamps)
            putBoolean("show_ai_avatar", newSettings.showAiAvatar)
            putBoolean("show_user_avatar", newSettings.showUserAvatar)
            putBoolean("rounded_bubbles", newSettings.roundedBubbles)
            putInt("bubble_corner_radius_dp", newSettings.bubbleCornerRadiusDp)
            putFloat("max_bubble_width_percent", newSettings.maxBubbleWidthPercent)
            putString("assistantName", newSettings.assistantName)
            putString("ai_personality", newSettings.aiPersonality)
            putString("response_length", newSettings.responseLength.name)
            putString("tone", newSettings.tone.name)
            putString("custom_instructions", newSettings.customInstructions)
            putString("custom_api_key", newSettings.customApiKey)
            putBoolean("is_logged_in", newSettings.isLoggedIn)
            putFloat("tts_speech_rate", newSettings.ttsSpeechRate)
            putFloat("tts_pitch", newSettings.ttsPitch)
            apply()
        }
        _settings.value = newSettings
    }

    fun resetToDefaults() {
        prefs.edit().clear().apply()
        _settings.value = loadSettings()
    }
}
