package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val modelUsed: String = "gemini-3.5-flash",
    val systemPromptOverride: String? = null
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String, // "user", "assistant", "system", "error"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val imageUris: String = "", // JSON or comma-separated base64 / uri
    val documentNames: String = "",
    val isStreaming: Boolean = false,
    val isError: Boolean = false
)
