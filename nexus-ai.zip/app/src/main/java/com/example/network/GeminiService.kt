package com.example.network

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

data class ChatMessagePayload(
    val role: String, // "user" or "model"
    val text: String,
    val imagesBase64: List<Pair<String, String>> = emptyList(), // Pair(mimeType, base64)
    val documentTexts: List<Pair<String, String>> = emptyList() // Pair(fileName, textContent)
)

class GeminiService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        private const val TAG = "GeminiService"
        const val DEFAULT_MODEL = "gemini-3.5-flash"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
    }

    /**
     * Streams responses from Gemini API using Server-Sent Events (SSE).
     */
    fun streamChat(
        history: List<ChatMessagePayload>,
        systemInstruction: String? = null,
        apiKeyOverride: String? = null,
        model: String = DEFAULT_MODEL,
        temperature: Float = 0.7f
    ): Flow<String> = flow {
        val activeApiKey = when {
            !apiKeyOverride.isNullOrBlank() -> apiKeyOverride.trim()
            BuildConfig.GEMINI_API_KEY.isNotEmpty() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY" -> BuildConfig.GEMINI_API_KEY
            else -> BuildConfig.GEMINI_API_KEY
        }

        if (activeApiKey.isBlank() || activeApiKey == "MY_GEMINI_API_KEY") {
            emit("⚠️ **Gemini API Key Required**\n\nPlease add your Gemini API Key in **Settings > Security & Privacy** or via the Secrets panel in AI Studio.\n\n*Get a free API key at [Google AI Studio](https://aistudio.google.com/)*.")
            return@flow
        }

        val requestJson = buildRequestBody(history, systemInstruction, temperature)
        val url = "$BASE_URL/$model:streamGenerateContent?alt=sse&key=$activeApiKey"

        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .addHeader("Accept", "text/event-stream")
            .build()

        val call = client.newCall(request)

        try {
            val response = withContext(Dispatchers.IO) { call.execute() }
            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "Unknown error"
                Log.e(TAG, "Gemini API error ${response.code}: $errorBody")
                val errorMsg = parseErrorMessage(errorBody, response.code)
                emit(errorMsg)
                return@flow
            }

            val body = response.body ?: run {
                emit("Error: Empty response body from AI server.")
                return@flow
            }

            body.byteStream().bufferedReader().use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    currentCoroutineContext().ensureActive()
                    val currentLine = line?.trim() ?: continue

                    if (currentLine.startsWith("data:")) {
                        val jsonData = currentLine.removePrefix("data:").trim()
                        if (jsonData.isNotEmpty() && jsonData != "[DONE]") {
                            val textChunk = parseChunkText(jsonData)
                            if (!textChunk.isNullOrEmpty()) {
                                emit(textChunk)
                            }
                        }
                    }
                }
            }
        } catch (e: CancellationException) {
            Log.d(TAG, "Stream cancelled by user.")
            call.cancel()
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Streaming error", e)
            emit("\n\n❌ **Network Error**: ${e.localizedMessage ?: "Failed to connect to AI server. Please check your internet connection."}")
        }
    }.flowOn(Dispatchers.IO)

    private fun buildRequestBody(
        history: List<ChatMessagePayload>,
        systemInstruction: String?,
        temperature: Float
    ): JSONObject {
        val root = JSONObject()

        // Contents array
        val contentsArray = JSONArray()
        for (msg in history) {
            val msgObj = JSONObject()
            msgObj.put("role", if (msg.role == "assistant" || msg.role == "model") "model" else "user")

            val partsArray = JSONArray()

            // Attached documents text
            for ((docName, docContent) in msg.documentTexts) {
                val partObj = JSONObject()
                partObj.put("text", "--- Attached File: $docName ---\n$docContent\n--- End File ---")
                partsArray.put(partObj)
            }

            // Attached images
            for ((mimeType, base64Data) in msg.imagesBase64) {
                val imgPart = JSONObject()
                val inlineData = JSONObject()
                inlineData.put("mimeType", mimeType)
                inlineData.put("data", base64Data)
                imgPart.put("inlineData", inlineData)
                partsArray.put(imgPart)
            }

            // Text message
            if (msg.text.isNotBlank() || partsArray.length() == 0) {
                val textPart = JSONObject()
                textPart.put("text", msg.text.ifBlank { "Analyze the attached content." })
                partsArray.put(textPart)
            }

            msgObj.put("parts", partsArray)
            contentsArray.put(msgObj)
        }
        root.put("contents", contentsArray)

        // System Instruction
        if (!systemInstruction.isNullOrBlank()) {
            val sysObj = JSONObject()
            val parts = JSONArray()
            val part = JSONObject()
            part.put("text", systemInstruction)
            parts.put(part)
            sysObj.put("parts", parts)
            root.put("systemInstruction", sysObj)
        }

        // Generation Config
        val genConfig = JSONObject()
        genConfig.put("temperature", temperature)
        root.put("generationConfig", genConfig)

        return root
    }

    private fun parseChunkText(jsonString: String): String? {
        return try {
            val obj = JSONObject(jsonString)
            val candidates = obj.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            if (parts.length() == 0) return null

            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                val text = part.optString("text", "")
                if (text.isNotEmpty()) {
                    sb.append(text)
                }
            }
            sb.toString()
        } catch (e: Exception) {
            null
        }
    }

    private fun parseErrorMessage(errorBody: String, statusCode: Int): String {
        return try {
            val obj = JSONObject(errorBody)
            val error = obj.optJSONObject("error")
            val message = error?.optString("message") ?: "HTTP error $statusCode"
            when (statusCode) {
                400 -> "⚠️ **Bad Request (400)**: $message"
                401, 403 -> "🔒 **Authentication Error ($statusCode)**: Invalid or unauthorized Gemini API Key. Please verify your key in Settings."
                429 -> "⏳ **Rate Limit Exceeded (429)**: The API quota was exceeded. Please wait a moment before trying again."
                else -> "❌ **Server Error ($statusCode)**: $message"
            }
        } catch (e: Exception) {
            "❌ **Error ($statusCode)**: $errorBody"
        }
    }
}

object ImageUtils {
    fun bitmapToBase64(bitmap: Bitmap, quality: Int = 85): String {
        val outputStream = ByteArrayOutputStream()
        // Resize bitmap if very large to prevent memory overhead and fast payload upload
        val maxDimension = 1200
        val scaledBitmap = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
            val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
            val targetWidth: Int
            val targetHeight: Int
            if (ratio > 1) {
                targetWidth = maxDimension
                targetHeight = (maxDimension / ratio).toInt()
            } else {
                targetHeight = maxDimension
                targetWidth = (maxDimension * ratio).toInt()
            }
            Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
        } else {
            bitmap
        }

        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    fun readStreamAsText(inputStream: InputStream, maxBytes: Int = 100_000): String {
        return inputStream.bufferedReader().use { reader ->
            val chars = CharArray(maxBytes)
            val read = reader.read(chars, 0, maxBytes)
            if (read > 0) String(chars, 0, read) else ""
        }
    }
}
