package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.UserSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app name string resource`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Nexus AI", appName)
    }

    @Test
    fun `user settings default configuration`() {
        val settings = UserSettings()
        assertEquals("Nexus AI", settings.assistantName)
        assertEquals(true, settings.roundedBubbles)
        assertNotNull(settings.customAccentColor)
    }
}
